let flowers = [];
let clouds = [];

function setup() {
  createCanvas(800, 600);
  
  // Cria nuvens iniciais
  for (let i = 0; i < 5; i++) {
    clouds.push({
      x: random(width),
      y: random(50, 150),
      size: random(80, 150),
      speed: random(0.2, 0.5)
    });
  }
}

function draw() {
  drawBackground();
  
  // Desenha e atualiza nuvens
  for (let cloud of clouds) {
    drawCloud(cloud);
    cloud.x += cloud.speed;
    if (cloud.x > width + 100) cloud.x = -100;
  }

  // Desenha flores
  for (let flower of flowers) {
    flower.update();
    flower.display();
  }
}

function drawBackground() {
  background(135, 206, 235); // Céu azul
  noStroke();
  fill(34, 139, 34); // Verde da grama
  rect(0, height * 0.75, width, height * 0.25);
}

function drawCloud(cloud) {
  fill(255);
  noStroke();
  ellipse(cloud.x, cloud.y, cloud.size, cloud.size * 0.6);
  ellipse(cloud.x + 30, cloud.y + 10, cloud.size * 0.7, cloud.size * 0.5);
  ellipse(cloud.x - 30, cloud.y + 10, cloud.size * 0.7, cloud.size * 0.5);
}

function mousePressed() {
  flowers.push(new Flower(mouseX, mouseY));
}

// Classe Flor
class Flower {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.size = 0;
    this.maxSize = random(20, 40);
    this.angle = random(TWO_PI);
    this.color = color(random(200, 255), random(100, 200), random(200, 255));
  }

  update() {
    if (this.size < this.maxSize) {
      this.size += 0.5;
    }
    this.angle += 0.05; // balanço suave
  }

  display() {
    push();
    translate(this.x, this.y);
    rotate(sin(this.angle) * 0.1);
    
    // Desenha pétalas
    for (let i = 0; i < 6; i++) {
      fill(this.color);
      ellipse(0, this.size / 2, this.size / 2, this.size);
      rotate(PI / 3);
    }

    // Centro da flor
    fill(255, 204, 0);
    ellipse(0, 0, this.size * 0.5);
    pop();
  }
}
